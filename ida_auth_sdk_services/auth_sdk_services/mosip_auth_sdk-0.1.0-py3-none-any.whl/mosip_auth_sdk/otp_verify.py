import json
import re
from mosip_auth_sdk import MOSIPAuthenticator
from dynaconf import Dynaconf


def load_config(config_path):
    """Load the configuration from a TOML file."""
    return Dynaconf(
        settings_files=[config_path],
        environments=False,
    )

def initialize_authenticator(config):
    """Initialize the MOSIP Authenticator with config."""
    return MOSIPAuthenticator(config=config)


def load_otp_data(filepath="otp_data.json"):
    """Load OTP data from JSON file."""
    with open(filepath, "r", encoding="utf-8") as f:
        return json.load(f)

def load_user_data(user_data_path):
    """Load user data from a JSON file."""
    with open(user_data_path, "r") as f:
        return json.load(f)


def validate_otp_data(otp_data):
    """Validate required fields and determine ID type."""
    individual_id = otp_data.get("individual_id", "").strip()
    otp_value = otp_data.get("otp_value", "").strip()
    txn_id = otp_data.get("txn_id", "").strip()

    if not individual_id or not otp_value or not txn_id:
        raise ValueError("Missing required field(s): individual_id, otp_value, or txn_id.")

    individual_id_type = "UIN" if len(individual_id) == 10 else "VID"
    return individual_id, otp_value, txn_id, individual_id_type


def authenticate_user_with_otp(
    authenticator,
    USER_DATA,
    OTP_VALUES,
    config_path
):
    """
    Main entry point for OTP-based authentication.

    Returns:
        dict: Parsed JSON response from the authenticator.
    """
    config = load_config(config_path)
    authenticator = initialize_authenticator(config)
    user_data = load_user_data(USER_DATA)
    otp_data = load_otp_data(OTP_VALUES)
    response = authenticator.auth(
        individual_id=user_data["individual_id"],
        individual_id_type=user_data.get("individual_id_type", "UIN"),
        otp_value=otp_data["otp"],
        consent=True,
        txn_id=otp_data["transaction_id"],
    )

    return response.json()
