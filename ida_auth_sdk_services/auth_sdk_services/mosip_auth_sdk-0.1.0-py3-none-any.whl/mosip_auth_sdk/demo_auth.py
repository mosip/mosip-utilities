import json
import sys
import re
from mosip_auth_sdk import MOSIPAuthenticator
from mosip_auth_sdk.models import DemographicsModel
from dynaconf import Dynaconf

def load_config(path):
    return Dynaconf(settings_files=[path], environments=False)

def initialize_authenticator(config):
    return MOSIPAuthenticator(config=config)

def load_user_data(filepath):
    with open(filepath, "r", encoding="utf-8") as f:
        return json.load(f)

def validate_user_data(user_data):
    language = user_data.get("language")
    if not language:
        raise ValueError("Missing 'language' field")

    individual_id = user_data.get("individual_id", "").strip()
    if not individual_id:
        raise ValueError("Missing 'individual_id'")

    individual_id_type = user_data.get("individual_id_type", "UIN").strip()

    dob = user_data.get("dob")
    if dob and not re.match(r"\d{4}/\d{2}/\d{2}$", dob):
        raise ValueError("Invalid DOB format. Use YYYY/MM/DD")

    return language, individual_id, individual_id_type

def wrap_localized(value, language):
    return [{"language": language, "value": value}] if value else None

def prepare_demographics(user_data, language):
    demographics_kwargs = {
        "name": wrap_localized(user_data.get("name"), language),
        "gender": wrap_localized(user_data.get("gender"), language),
        "fullAddress": wrap_localized(user_data.get("full_address"), language),
        "dob": user_data.get("dob"),
        "email": user_data.get("email_id"),
    }
    demographics_cleaned = {k: v for k, v in demographics_kwargs.items() if v}
    if not demographics_cleaned:
        raise ValueError("No valid demographic data provided.")
    return DemographicsModel(**demographics_cleaned)

def authenticate_from_json_file(json_path, config_path='settings.toml'):
    config = load_config(config_path)
    authenticator = initialize_authenticator(config)
    user_data = load_user_data(json_path)
    language, individual_id, individual_id_type = validate_user_data(user_data)
    demographics_data = prepare_demographics(user_data, language)

    response = authenticator.auth(
        individual_id=individual_id,
        individual_id_type=individual_id_type,
        demographic_data=demographics_data,
        consent=True,
    )

    return response.json()
