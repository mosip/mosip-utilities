import json
from mosip_auth_sdk import MOSIPAuthenticator
from dynaconf import Dynaconf


def load_config(config_path):
    """Load the configuration from a TOML file."""
    return Dynaconf(
        settings_files=[config_path],
        environments=False,
    )


def initialize_authenticator(config):
    """Initialize MOSIP Authenticator with config."""
    return MOSIPAuthenticator(config=config)


def load_user_data(user_data_path):
    """Load user data from a JSON file."""
    with open(user_data_path, "r") as f:
        return json.load(f)


def generate_otp(
    user_data_path,
    config_path
):
    """
    Generate OTP using user data in a JSON file.
    
    Expected JSON format:
    {
        "individual_id": "123456789012",
        "individual_id_type": "UIN",  # or "VID"
        "email": true,
        "phone": true
    }
    """
    user_data = load_user_data(user_data_path)
    
    config = load_config(config_path)
    authenticator = initialize_authenticator(config)

    response = authenticator.genotp(
        individual_id=user_data["individual_id"],
        individual_id_type=user_data.get("individual_id_type", "UIN"),
        email=user_data.get("email", True),
        phone=user_data.get("phone", True),
    )

    response_body = response.json()
    errors = response_body.get("errors") or []

    if errors:
        raise Exception(
            f"OTP Generation failed: {[(e['errorCode'], e['errorMessage']) for e in errors]}"
        )

    return response_body
